use [Punto-De-Venta]
go

-- 3 Triggers Update, Insert, Delete (instead of, after)

create trigger [dbo].[Ventas_Update]
on [dbo].[Venta]
instead of update
as
begin
	select *
	from INSERTED
	print'No est� permitido actualizar los datos de la Tabla de Ventas'
END

update Venta set Total = 15000 where Id_Venta = 2;
select * from Venta;
drop trigger Ventas_Update;


create trigger [dbo].[Ventas_Delete]
on [dbo].[Venta]
instead of delete
as
begin
	select *
	from DELETED
	print'No est� permitido borrar los datos de la tabla Productos'
END

insert into Venta (Id_Venta, Subtotal, IVA, Total, [Fecha/Hora], Id_Vendedor, Id_Cliente, Id_Caja) values (5, 13999, 2099, 16098, '2015-11-13 18:13:24', 3, 2, 3);
delete from Venta where Id_Venta = 5;
select * from Venta;
drop trigger Ventas_Delete;


create trigger [dbo].[Vendedor_Insert]
on [dbo].[Vendedor]
after insert
as
begin
	select *
	from INSERTED
END

insert into Vendedor (Id_Vendedor, Nombre, PrimerApellido, SegundoApellido, [R.F.C], Id_Domicilio, Id_Sucursal) values (5, 'Jos� Luis', 'Santos', 'Olmeda', 'SAOJ3405103SA', 1, 3);
delete from Vendedor where Id_Vendedor = 5;
select * from Vendedor;
drop trigger Vendedor_Insert;