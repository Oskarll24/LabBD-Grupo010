use [Punto-De-Venta]
go

--1 Procedimiento Script (Tirar y Crear tabla)

create procedure [dbo].[TirarCrearTabla]
as
begin

	select *
	into #ListaDePreciosRespaldo
	from ListaDePrecios;

	drop table ListaDePrecios;

	create table ListaDePrecios(Id_ListaDePrecios int, Precio money, FechaInicial date, FechaFinal date, Id_Producto int);
	insert into ListaDePrecios select * from #ListaDePreciosRespaldo;

	select * from ListaDePrecios;

end
GO

exec [TirarCrearTabla];


--5 Procedimientos de tipo 'Consulta' donde filtren los reportes de la pr�ctica pasada

create procedure [dbo].[Informaci�nEmpleado](@ValorNoInt varchar(30))
as
begin

	select * from Direcci�nDeEmpleados
	where [No.Int] = @ValorNoInt;

end
GO

exec Informaci�nEmpleado 3312;


create procedure [dbo].[Informaci�nProducto](@ValorMarca varchar(50))
as
begin

	select NombreDeProducto, NombreDistribuidor from DistribuidorDeProductos
	where Marca = @ValorMarca;

end
GO

exec Informaci�nProducto ASUS;


create procedure [dbo].[Informaci�nVentas](@ValorNombre varchar(MAX))
as
begin

	select [Nombre Completo], Total, [Fecha/Hora] from VentasDeEmpleados
	where [Nombre Completo] = @ValorNombre;

end
GO

exec Informaci�nVentas [Omar Santos Olmeda];


create procedure [dbo].[Informaci�nPrecios](@ValorNombreProducto varchar(50))
as
begin

	select NombreDeProducto, Marca, Precio, FechaInicial, FechaFinal from PreciosDeProductos
	where NombreDeProducto = @ValorNombreProducto;

end
GO

exec Informaci�nPrecios [Portatil X556U];


create procedure [dbo].[Informaci�nVentasTotales](@ValorTotal money)
as
begin

	select * from ReporteMensual
	where Total = @ValorTotal;

end
GO

exec Informaci�nVentasTotales 1760.00;


--1 Funci�n

create function [dbo].[fn.Multiplicaci�n](@valor1 int, @valor2 int)
returns int
as
begin

	return @valor1 * @valor2

end
GO

select dbo.[fn.Multiplicaci�n](10000,5) as Total;


--Drops
drop procedure TirarCrearTabla;
drop procedure Informaci�nEmpleado;
drop procedure Informaci�nProducto;
drop procedure Informaci�nVentas;
drop procedure Informaci�nPrecios;
drop procedure Informaci�nVentasTotales;
drop function dbo.[fn.Multiplicaci�n];