use [Punto-De-Venta]
go

--5 Selects B�sicos:
select distinct Nombre from Vendedor;
select Nombre as 'NombreEstado' from Estado;
select top 2 Total, [Fecha/Hora] from Venta;
select tp.Tipo as 'TipoProducto' from TipoProducto as tp;
select Nombre + ' ' + PrimerApellido + ' ' + SegundoApellido as 'NombreCompleto' from Vendedor;


--4 Selects JOIN
select s.Nombre as 'NombreTienda', d.NombreCalle, d.[No.Ext] from Sucursal as s left join Domicilio as d on s.Id_Domicilio = d.Id_Domicilio;
select s.Nombre as 'NombreTienda', d.NombreCalle, d.[No.Ext] from Sucursal as s right join Domicilio as d on s.Id_Domicilio = d.Id_Domicilio;
select v.Nombre, v.PrimerApellido, v.[R.F.C], d.NombreCalle, d.[No.Int] from Vendedor as v cross join Domicilio as d where v.Id_Domicilio = d.Id_Domicilio;
select v.Nombre + ' ' + v.PrimerApellido + ' ' + v.SegundoApellido as 'NombreCompleto', v.[R.F.C], v.Id_Domicilio, d.NombreCalle, d.[No.Int] from Vendedor as v inner join Domicilio as d on d.Id_Domicilio = v.Id_Vendedor;


--5 Selects WHERE
select * from Venta where Total >= 10000;
select * from CantidadProducto where Estatus = 1;
select Nombre, Descripcion from Producto where Marca = 'ASUS';
select PrimerApellido, SegundoApellido, [R.F.C] from Vendedor where Nombre = 'John';
select FechaInicial, Precio, FechaFinal from ListaDePrecios where Precio <= 15000 order by FechaInicial desc;

--5 Selects con Funciones de Agregaci�n
select min(Total) as 'VentaM�nima' from Venta;
select max(Total) as 'VentaM�xima' from Venta;
select Total, count(Total) as 'Cantidad' from Venta group by Total having count(Total) <= 1;
select FechaInicial, avg(Precio) as 'PromedioDePrecios' from ListaDePrecios group by FechaInicial;
select Subtotal, IVA, sum(Subtotal + IVA) as 'TotalVenta', [Fecha/Hora] from Venta group by Subtotal, IVA, [Fecha/Hora];

--3 Selects con JOIN y GROUP BY
select s.Nombre as 'NombreTienda', d.NombreCalle, d.[No.Ext] from Sucursal as s left join Domicilio as d on s.Id_Domicilio = d.Id_Domicilio group by s.Nombre, d.NombreCalle, d.[No.Ext];
select v.Nombre, v.PrimerApellido, v.[R.F.C], d.NombreCalle, d.[No.Int] from Vendedor as v cross join Domicilio as d where v.Id_Domicilio = d.Id_Domicilio group by v.Nombre, v.PrimerApellido, v.[R.F.C], d.NombreCalle, d.[No.Int];
select v.Nombre + ' ' + v.PrimerApellido + ' ' + v.SegundoApellido as 'NombreCompleto', v.[R.F.C], v.Id_Domicilio, d.NombreCalle, d.[No.Int] from Vendedor as v inner join Domicilio as d on d.Id_Domicilio = v.Id_Vendedor group by v.Nombre, v.PrimerApellido, v.SegundoApellido, v.[R.F.C], v.Id_Domicilio, d.NombreCalle, d.[No.Int];

--1 Select INTO con DROP TABLE y Reinsertar
select *
into #ListaDePreciosRespaldo
from ListaDePrecios;

drop table ListaDePrecios;

create table ListaDePrecios(Id_ListaDePrecios int, Precio money, FechaInicial date, FechaFinal date, Id_Producto int)
insert into ListaDePrecios select * from #ListaDePreciosRespaldo;

select * from ListaDePrecios;