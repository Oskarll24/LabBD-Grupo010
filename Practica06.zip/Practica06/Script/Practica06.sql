use [Punto-De-Venta]
go

-- 3 Subconsultas
	--1 subconsulta de tabla
	--1 subconsulta de columna
	--1 a elecci�n

select Nombre, [R.F.C.]
from Distribuidor
where Id_Distribuidor = (select Id_Producto from Producto where Id_Producto = 3);

select top 2 *
from
	(
		select Nombre, (
							select count(Nombre)
							from Vendedor as V
							where V.Nombre = Vendedor.Nombre
						) as [Cantidad]
		from Vendedor
	) as NC
where NC.Cantidad = 1;

select top 1 *
from
	(
		select Total, (
							select count(Total)
							from Venta as Ven
							where Ven.Total = Venta.Total
						) as [Cantidad]
		from Venta
	) as NC
where NC.Cantidad > 1;


-- 1 Subconsulta con WITH

with NC as (
select Nombre + ' ' + PrimerApellido + ' ' + SegundoApellido as [Nombre Completo]
	from Vendedor
)

select *
from NC;


-- 5 Vistas
-- La consulta tiene que ser un reporte de su aplicaci�n
	--JOIN
	--Funci�n de agregaci�n

create view Direcci�nDeEmpleados as
select (v.Nombre + ' ' + v.PrimerApellido + ' ' + v.SegundoApellido) as [Nombre Completo], d.NombreCalle, d.[No.Int]
from Vendedor as v left join Domicilio as d on v.Id_Vendedor = d.Id_Domicilio;

select * from Direcci�nDeEmpleados;

create view DistribuidorDeProductos as
select p.Nombre as NombreDeProducto, p.Marca, p.[No.Serie], d.Nombre as NombreDistribuidor, d.[R.F.C.]
from Producto as p left join Distribuidor as d on p.Id_Producto = d.Id_Distribuidor;

select * from DistribuidorDeProductos;

create view VentasDeEmpleados as
select (v.Nombre + ' ' + v.PrimerApellido + ' ' + v.SegundoApellido) as [Nombre Completo], v.[R.F.C], ven.Total, ven.[Fecha/Hora]
from Venta as ven left join Vendedor as v on v.Id_Vendedor = ven.Id_Venta;

select * from VentasDeEmpleados;

create view PreciosDeProductos as
select p.Nombre as NombreDeProducto, p.Marca, p.[No.Serie], ldp.Precio, ldp.FechaInicial, ldp.FechaFinal
from Producto as p left join ListaDePrecios as ldp on ldp.Id_ListaDePrecios = p.Id_Producto;

select * from PreciosDeProductos;

create view ReporteMensual as (

select (v.Nombre + ' ' + v.PrimerApellido + ' ' + v.SegundoApellido) as [Nombre Completo], ven.Total, ven.[Fecha/Hora], count(ven.Id_Venta) as [VentasTotales]
from Vendedor as v left join Venta as ven on ven.Id_Venta = v.Id_Vendedor 
group by v.Nombre + ' ' + v.PrimerApellido + ' ' + v.SegundoApellido, ven.Total, ven.[Fecha/Hora]);

select * from ReporteMensual;


-- 1 Consulta Din�mica

declare @query varchar(MAX)
declare @NombreCompleto varchar(MAX) = '[Nombre del Empleado]'

set @query = 'select Nombre + PrimerApellido + SegundoApellido as ' + @NombreCompleto + ' from Vendedor'
print(@query)
exec(@query);