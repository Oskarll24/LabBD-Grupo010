--insert

select * from Estado;

insert into Estado (Id_Estado, Nombre) values (1, 'Nuevo Le�n');
insert into Estado (Id_Estado, Nombre) values (2, 'Oaxaca');
insert into Estado (Id_Estado, Nombre) values (3, 'Sinaloa');
insert into Estado (Id_Estado, Nombre) values (4, 'Jalisco');
insert into Estado (Id_Estado, Nombre) values (5, 'Veracruz');

select * from Municipio;

insert into Municipio (Id_Municipio, Nombre, Id_Estado) values (1, 'Monterrey', 1);
insert into Municipio (Id_Municipio, Nombre, Id_Estado) values (2, 'Ayotzintepec', 2);
insert into Municipio (Id_Municipio, Nombre, Id_Estado) values (3, 'Culiac�n', 3);
insert into Municipio (Id_Municipio, Nombre, Id_Estado) values (4, 'Guadalajara', 4);
insert into Municipio (Id_Municipio, Nombre, Id_Estado) values (5, 'Acula', 5);

select * from Colonia;

insert into Colonia (Id_Colonia, Nombre, [C.P.], Id_Municipio) values (1, 'Valle de Santa Lucia', 64230, 1);
insert into Colonia (Id_Colonia, Nombre, [C.P.], Id_Municipio) values (2, 'San Jos� Mano Marqu�s', 68438, 2);
insert into Colonia (Id_Colonia, Nombre, [C.P.], Id_Municipio) values (3, '16 de Septiembre', 80016, 3);
insert into Colonia (Id_Colonia, Nombre, [C.P.], Id_Municipio) values (4, '5 de Mayo', 44970, 4);

select * from Domicilio;

insert into Domicilio (Id_Domicilio, NombreCalle, [No.Int], [No.Ext], Id_Colonia) values (1, 'Manuel M Di�guez', 3312, 3, 1);
insert into Domicilio (Id_Domicilio, NombreCalle, [No.Int], [No.Ext], Id_Colonia) values (2, 'San Mar�a Jacatepec', 4215, 7, 2);
insert into Domicilio (Id_Domicilio, NombreCalle, [No.Int], [No.Ext], Id_Colonia) values (3, 'Santiago Tapia', 3414, 6, 3);
insert into Domicilio (Id_Domicilio, NombreCalle, [No.Int], [No.Ext], Id_Colonia) values (4, 'Su�rez', 5132, 3, 4);

select * from Cliente;

insert into Cliente (Id_Cliente, Id_Direccion) values (1, 1);
insert into Cliente (Id_Cliente, Id_Direccion) values (2, 2);
insert into Cliente (Id_Cliente, Id_Direccion) values (3, 3);
insert into Cliente (Id_Cliente, Id_Direccion) values (4, 4);

select * from Caja;

insert into Caja (Id_Caja, [No.Caja]) values (1, 1);
insert into Caja (Id_Caja, [No.Caja]) values (2, 2);
insert into Caja (Id_Caja, [No.Caja]) values (3, 3);
insert into Caja (Id_Caja, [No.Caja]) values (4, 4);
insert into Caja (Id_Caja, [No.Caja]) values (5, 5);

select * from TipoProducto;

insert into TipoProducto (Id_TipoProducto, Tipo) values (1, 'Celular');
insert into TipoProducto (Id_TipoProducto, Tipo) values (2, 'ComputadorDeEscritorio');
insert into TipoProducto (Id_TipoProducto, Tipo) values (3, 'Impresora');
insert into TipoProducto (Id_TipoProducto, Tipo) values (4, 'Laptop');

select * from Distribuidor;

insert into Distribuidor (Id_Distribuidor, Nombre, [R.F.C.]) values (1, 'ISP', 'AACJ370418CH6');
insert into Distribuidor (Id_Distribuidor, Nombre, [R.F.C.]) values (2, 'Casman', 'AIOA531015QF2');
insert into Distribuidor (Id_Distribuidor, Nombre, [R.F.C.]) values (3, 'Estiromat', 'CATC901002631');
insert into Distribuidor (Id_Distribuidor, Nombre, [R.F.C.]) values (4, 'Electr�nica Lindel', 'TOHR340510E13');

select * from ProductosComprados;

insert into ProductosComprados (Id_ProductosComprados, CantidadComprados, Costo) values (1, 64, 3500);
insert into ProductosComprados (Id_ProductosComprados, CantidadComprados, Costo) values (2, 13, 1600);
insert into ProductosComprados (Id_ProductosComprados, CantidadComprados, Costo) values (3, 51, 2300);
insert into ProductosComprados (Id_ProductosComprados, CantidadComprados, Costo) values (4, 22, 2000);

select * from Producto;

insert into Producto (Id_Producto, Nombre, Marca, Descripcion, [No.Serie], Id_TipoProducto, Id_Distribuidor) values (1, '�Phone 7', 'Apple', 'Tel�fono Inteligente', 'N9TT-9G0A-B7FQ-RANC', 1, 1);
insert into Producto (Id_Producto, Nombre, Marca, Descripcion, [No.Serie], Id_TipoProducto, Id_Distribuidor) values (2, 'Computadora Powered', 'ASUS', 'PC Tipo Torre de Serie Gaming', 'QK6A-JI6S-7ETR-0A6C', 2, 2);
insert into Producto (Id_Producto, Nombre, Marca, Descripcion, [No.Serie], Id_TipoProducto, Id_Distribuidor) values (3, 'Impresora DeskJet', 'HP', 'Impresora Compacta Multifuncional de Tinta, Color Azul', 'SXFP-CHYK-ONI6-S89U', 3, 3);
insert into Producto (Id_Producto, Nombre, Marca, Descripcion, [No.Serie], Id_TipoProducto, Id_Distribuidor) values (4, 'Laptop X556U', 'ASUS', 'Ordenador Port�til de Series X556U', '6ETI-UIL2-9WAX-XHYO', 3, 4);

select * from CantidadProducto;

insert into CantidadProducto (Id_CantidadProducto, Estatus, Cantidad, Id_Producto) values (1, 1, 64, 1);
insert into CantidadProducto (Id_CantidadProducto, Estatus, Cantidad, Id_Producto) values (2, 1, 74, 2);
insert into CantidadProducto (Id_CantidadProducto, Estatus, Cantidad, Id_Producto) values (3, 1, 53, 3);
insert into CantidadProducto (Id_CantidadProducto, Estatus, Cantidad, Id_Producto) values (4, 1, 22, 4);

select * from Almacen;

insert into Almacen (Id_Almacen, Id_CantidadProducto, Id_TipoProducto, Id_Domicilio) values (1, 1, 1, 1);
insert into Almacen (Id_Almacen, Id_CantidadProducto, Id_TipoProducto, Id_Domicilio) values (2, 2, 2, 2);
insert into Almacen (Id_Almacen, Id_CantidadProducto, Id_TipoProducto, Id_Domicilio) values (3, 3, 3, 3);
insert into Almacen (Id_Almacen, Id_CantidadProducto, Id_TipoProducto, Id_Domicilio) values (4, 4, 4, 4);

select * from Inventario;

insert into Inventario (Id_Inventario, Fecha, Id_Almacen, Id_Producto) values (1, '29 -Jun-04', 1, 1);
insert into Inventario (Id_Inventario, Fecha, Id_Almacen, Id_Producto) values (2, '10 -Dec-05', 2, 2);
insert into Inventario (Id_Inventario, Fecha, Id_Almacen, Id_Producto) values (3, '31 -AUG-06', 3, 3);
insert into Inventario (Id_Inventario, Fecha, Id_Almacen, Id_Producto) values (4, '12 -Dec-07', 4, 4);

select * from Sucursal;

insert into Sucursal (Id_Sucursal, Nombre, Id_Almacen, Id_Domicilio) values (1, 'MacStore', 1, 1);
insert into Sucursal (Id_Sucursal, Nombre, Id_Almacen, Id_Domicilio) values (2, 'ASUS M�xico', 2, 2);
insert into Sucursal (Id_Sucursal, Nombre, Id_Almacen, Id_Domicilio) values (3, 'Store HP', 3, 3);
insert into Sucursal (Id_Sucursal, Nombre, Id_Almacen, Id_Domicilio) values (4, 'ASUS M�xico', 4, 4);

select * from ListaDePrecios;

insert into ListaDePrecios (Id_ListaDePrecios, Precio, FechaInicial, FechaFinal, Id_Producto) values (1, 13999, '29 -Jun-04', '29 -Jun-05', 1);
insert into ListaDePrecios (Id_ListaDePrecios, Precio, FechaInicial, FechaFinal, Id_Producto) values (2, 13859, '10 -Dec-05', '10 -Dec-06', 2);
insert into ListaDePrecios (Id_ListaDePrecios, Precio, FechaInicial, FechaFinal, Id_Producto) values (3, 1531, '31 -AUG-06', '31 -AUG-07', 3);
insert into ListaDePrecios (Id_ListaDePrecios, Precio, FechaInicial, FechaFinal, Id_Producto) values (4, 14500, '12 -Dec-07', '12 -Dec-08', 4);

select * from Vendedor;

insert into Vendedor (Id_Vendedor, Nombre, PrimerApellido, SegundoApellido, [R.F.C], Id_Domicilio, Id_Sucursal) values (1, 'Omar', 'Santos', 'Olmeda', 'SAOO340510FF8', 1, 1);
insert into Vendedor (Id_Vendedor, Nombre, PrimerApellido, SegundoApellido, [R.F.C], Id_Domicilio, Id_Sucursal) values (2, 'John', 'Hierro', 'Alejo', 'HIAJ340510TB3', 2, 2);
insert into Vendedor (Id_Vendedor, Nombre, PrimerApellido, SegundoApellido, [R.F.C], Id_Domicilio, Id_Sucursal) values (3, 'Jos�', 'Monsiv�is', 'Rojas', 'MORJ340510A10', 3, 3);
insert into Vendedor (Id_Vendedor, Nombre, PrimerApellido, SegundoApellido, [R.F.C], Id_Domicilio, Id_Sucursal) values (4, 'Ver�nica', 'Ram�n', 'Palacios', 'RAPV340510322', 4, 4);
insert into Vendedor (Id_Vendedor, Nombre, PrimerApellido, SegundoApellido, [R.F.C], Id_Domicilio, Id_Sucursal) values (5, 'Jos� Luis', 'Santos', 'Olmeda', 'SAOJ3405103SA', 1, 3);

select * from Venta;

insert into Venta (Id_Venta, Subtotal, IVA, Total, [Fecha/Hora], Id_Vendedor, Id_Cliente, Id_Caja) values (1, 13999, 2099, 16098, '2011-06-13 13:17:17', 1, 1, 1);
insert into Venta (Id_Venta, Subtotal, IVA, Total, [Fecha/Hora], Id_Vendedor, Id_Cliente, Id_Caja) values (2, 13859, 2078, 15937, '2012-12-17 15:15:25', 2, 2, 2);
insert into Venta (Id_Venta, Subtotal, IVA, Total, [Fecha/Hora], Id_Vendedor, Id_Cliente, Id_Caja) values (3, 1531, 229, 1760, '2013-03-18 12:22:13', 3, 3, 3);
insert into Venta (Id_Venta, Subtotal, IVA, Total, [Fecha/Hora], Id_Vendedor, Id_Cliente, Id_Caja) values (4, 14500, 2175, 16675, '2014-05-25 16:20:11', 4, 4, 4);
insert into Venta (Id_Venta, Subtotal, IVA, Total, [Fecha/Hora], Id_Vendedor, Id_Cliente, Id_Caja) values (5, 13999, 2099, 16098, '2015-11-13 18:13:24', 3, 2, 3);

select * from ProductosVendidos;

insert into ProductosVendidos (Id_ProductosVendidos, Precio, Id_Venta, Id_ProductosComprados, Id_Inventario) values (1, 13999, 1, 1, 1);
insert into ProductosVendidos (Id_ProductosVendidos, Precio, Id_Venta, Id_ProductosComprados, Id_Inventario) values (2, 13859, 2, 2, 2);
insert into ProductosVendidos (Id_ProductosVendidos, Precio, Id_Venta, Id_ProductosComprados, Id_Inventario) values (3, 1531, 3, 3, 3);
insert into ProductosVendidos (Id_ProductosVendidos, Precio, Id_Venta, Id_ProductosComprados, Id_Inventario) values (4, 14500, 4, 4, 4);


--update

select * from Vendedor;

update Vendedor set Nombre = 'Jose' where Id_Vendedor = 5;

select * from Caja;

update Caja set [No.Caja] = 6 where Id_Caja = 5;

select * from Sucursal;

update Sucursal set Nombre = 'ASUS USA' where Id_Sucursal = 4;

select * from CantidadProducto;

update CantidadProducto set Cantidad = 120 where Id_CantidadProducto = 4;

select * from Producto;

update Producto set Nombre = 'Portatil X556U' where Id_Producto = 4;


--delete

select * from Vendedor;

delete from Vendedor where Id_Vendedor = 5;

select * from Caja;

delete from Caja where Id_Caja = 5;

select * from Venta;

delete from Venta where Id_Venta = 5;

select * from Estado;

delete from Estado where Id_Estado = 5;

select * from Municipio;

delete from Municipio where Id_Municipio = 5;